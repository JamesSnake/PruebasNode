'use strict'

const mapper = require("json2json-transform")
const config = require("../../Config/Config")
const utils = require("../Util")
const NumetricCon = require("./NumetricConnector")
const datasetsMixPanel = require("../../Model/datasetsMixPanel")


function NumetricMixPanelFormat(inputData){
	var conf = new config();
 var result = mapper.transform(inputData, conf.parameters().plantillaJsonDestino, conf.operations);
 return result[""];
}


function updateRowsMixPanel(inputMixPanel){
	var JsonResult = {};
	JsonResult["rows"] = [];
	if(utils.isArray(inputMixPanel)){
		for (var i = 0; i < inputMixPanel.length; i++ ){
			var row = NumetricMixPanelFormat(inputMixPanel[i]);
			utils.GenerateRowsFromMixPanel(row,JsonResult["rows"]);
		}
	} else {
			var row = NumetricMixPanelFormat(inputMixPanel);
			utils.GenerateRowsFromMixPanel(row,JsonResult["rows"]);
	}
	NumetricCon.updateRowsDataSetNumetric("374bdb59-c2ce-49c6-b181-bfd8f6a36c8c",JsonResult);
}

var generateDataSetMixPanelAux = function(inputMixPanel){

var conf = new config();
var finalFormatMixPanel = NumetricMixPanelFormat(inputMixPanel);
var datasetmixpanel = utils.GenerateDataSetsNumetricFromMixPanel(finalFormatMixPanel);
console.log(datasetmixpanel.DataSetList[0])

} 

var generateDataSetMixPanel = function(){
  if(datasetsMixPanel.datasetMixPanelEventId == ""){
  	//var datasetId = NumetricCon.generateDataSetNumetric(datasetsMixPanel.datasetMixPanelEvent);
  	//datasetsMixPanel.datasetMixPanelEventId = "";
  	datasetsMixPanel.datasetMixPanelEventId = {id:"374bdb59-c2ce-49c6-b181-bfd8f6a36c8c"};
  }
}

var RunConnectorMixPanel =  function(){

	NumetricCon.getDataSetNumetric().then(listDataset=>{
	if(!listDataset==false){
		//recorrer la lista para encontrar 
		//si no existe crear
		//llamar al metodo de anderson para obtener la data de event 
		//Llamar al metodo que actualiza el data set
	});
});


}


var testPreserveValue = function(){
	console.log(datasetsMixPanel.datasetMixPanelEventId);
}


module.exports={
	updateRowsMixPanel : updateRowsMixPanel,
	generateDataSetMixPanel : generateDataSetMixPanel,
	testPreserveValue : testPreserveValue
}