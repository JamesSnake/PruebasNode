'use strict'

const mapper = require("json2json-transform")
const config = require("../../Config/Config")
const utils = require("../Util")
const NumetricCon = require("./NumetricConnector")
const datasetsMixPanel = require("../../Model/datasetsMixPanel")


function NumetricMixPanelFormat(inputData){
	var conf = new config();
 var result = mapper.transform(inputData, conf.parameters().plantillaJsonDestino, conf.operations);
 return result[""];
}


function updateRowsMixPanel(inputMixPanel){
	var JsonResult = {};
	JsonResult["rows"] = [];
	if(utils.isArray(inputMixPanel)){
		for (var i = 0; i < inputMixPanel.length; i++ ){
			var row = NumetricMixPanelFormat(inputMixPanel[i]);
			utils.GenerateRowsFromMixPanel(row,JsonResult);
		}
	} else {
			var row = NumetricMixPanelFormat(inputMixPanel);
			utils.GenerateRowsFromMixPanel(row,JsonResult);
	}
	NumetricCon.updateRowsDataSetNumetric(datasetsMixPanel.datasetMixPanelEventId.id,JsonResult);
}

var generateDataSetMixPanelAux = function(inputMixPanel){

var conf = new config();
var finalFormatMixPanel = NumetricMixPanelFormat(inputMixPanel);
var datasetmixpanel = utils.GenerateDataSetsNumetricFromMixPanel(finalFormatMixPanel);
console.log(datasetmixpanel.DataSetList[0])

} 

var generateDataSetMixPanel = function(){
  if(datasetsMixPanel.datasetMixPanelEventId == ""){
  	//var datasetId = NumetricCon.generateDataSetNumetric(datasetsMixPanel.datasetMixPanelEvent);
  	//datasetsMixPanel.datasetMixPanelEventId = "";
  	datasetsMixPanel.datasetMixPanelEventId = {id:"374bdb59-c2ce-49c6-b181-bfd8f6a36c8c"};
  }
}

var verifyDatasetMixPanel = function(){
	var found;
	return NumetricCon.getDataSetNumetric().then(result=>{
	if(result.error==false){

		for (var i = 0; i < result.response.length; i++ ) {
			if(result.response[i].name==datasetsMixPanel.datasetMixPanelEvent.name){
				found=true;
				console.log(result.response[i].id);
				datasetsMixPanel.datasetMixPanelEventId = {id:result.response[i].id};
				return {error:false};
			}
		}

		if(!found){
			NumetricCon.generateDataSetNumetric(datasetsMixPanel.datasetMixPanelEvent).then(result=>{
				if(result.error==false){
					datasetsMixPanel.datasetMixPanelEventId = result.response;
				}
				return {error:result.error};
			});
		}
	}
});
}


var testPreserveValue = function(){
	console.log(datasetsMixPanel.datasetMixPanelEventId);
}


module.exports={
	updateRowsMixPanel : updateRowsMixPanel,
	generateDataSetMixPanel : generateDataSetMixPanel,
	testPreserveValue : testPreserveValue,
	verifyDatasetMixPanel : verifyDatasetMixPanel
}