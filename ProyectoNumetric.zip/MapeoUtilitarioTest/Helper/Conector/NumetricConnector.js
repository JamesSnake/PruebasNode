'use strict'

const config = require("../../Config/Config")
const rp = require('request-promise')
//const seq = require("../../sequence").Sequence

var getDataSetNumetric = function(){
	var conf = new config();
	var err;
	var result;
	return rp(conf.parameters().optionsGetDataSet).then(response =>{
		     //console.log(response);
		     return {error:false,response:response};
			})
			.catch(function(err){ 
			    console.log("error atrapado");
			    return {error:true,response:null};
			});
/*var sequence = seq.create()
sequence
   .then(function(next) {
   	 console.log("paso1");
     rp(conf.parameters().optionsGetDataSet).then(response =>{
      next(err,response);
	})
	.catch(function(err){ 
	    console.log("error atrapado");
	    err = true;
	    next(err,null);
	});
  })
  .then(function(next,err,response) {
  	console.log("paso 2");
  	 if(err){
  	 	console.log("ocurrio un error");
  	 }else{
  	 	result = response;
  	 	console.log(response);
  	 }
  });*/
}

var getDataSetNumetricById = function(datasetId){
	var conf = new config(datasetId);
	return rp(conf.parameters().optionsGetDataSetById).then(response =>{
     console.log(response);
     return response;
	});
}

var generateDataSetNumetric = function(data){
	var conf = new config();
	return rp(conf.parameters(data).optionsCreateDataSet).then(response =>{
     console.log(response);
     return response;
	});
}

var updateRowsDataSetNumetric = function(datasetId,data){
	var conf = new config(datasetId);
	return rp(conf.parameters(data).optionsUpdateRowsDataSet).then(response =>{
     console.log(response);
     return response;
	});
}

var getRowsDataSetNumetric = function(datasetId){
	var conf = new config(datasetId);
	return rp(conf.parameters().optionsGetRowsDataSet).then(response =>{
     //console.log(response);
     return response;
	});
}

var deleteRowsDataSetNumetric = function(datasetId,data){
	var conf = new config(datasetId);
	return rp(conf.parameters(data).optionsDeleteRowsDataSet).then(response =>{
     console.log(response);
     return response;
	});
}

module.exports = {
	getDataSetNumetric: getDataSetNumetric,
	getDataSetNumetricById : getDataSetNumetricById,
	generateDataSetNumetric : generateDataSetNumetric,
	updateRowsDataSetNumetric : updateRowsDataSetNumetric,
	getRowsDataSetNumetric: getRowsDataSetNumetric,
	deleteRowsDataSetNumetric : deleteRowsDataSetNumetric
}